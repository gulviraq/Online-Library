using System.ComponentModel.DataAnnotations;

namespace LibraryWebsite.Models;

public class Book
{
    public int Id { get; set; }
    [Required, StringLength(150)]
    public string Title { get; set; } = "";
    [Required, StringLength(120)]
    public string Author { get; set; } = "";
    [Range(1000, 2100)]
    public int Year { get; set; }
    public bool IsAvailable { get; set; } = true;
}
