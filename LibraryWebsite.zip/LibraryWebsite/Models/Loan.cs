namespace LibraryWebsite.Models;

public class Loan
{
    public int Id { get; set; }
    public int BookId { get; set; }
    public Book? Book { get; set; }
    public int ReaderId { get; set; }
    public Reader? Reader { get; set; }
    public DateTime BorrowedAt { get; set; } = DateTime.Today;
    public DateTime DueDate { get; set; } = DateTime.Today.AddDays(14);
    public DateTime? ReturnedAt { get; set; }
    public bool IsReturned => ReturnedAt.HasValue;
    public int OverdueDays => ReturnedAt.HasValue
        ? Math.Max(0, (ReturnedAt.Value.Date - DueDate.Date).Days)
        : Math.Max(0, (DateTime.Today - DueDate.Date).Days);
    public decimal Fine => OverdueDays * 100m;
}
