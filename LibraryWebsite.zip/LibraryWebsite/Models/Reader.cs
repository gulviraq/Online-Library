using System.ComponentModel.DataAnnotations;

namespace LibraryWebsite.Models;

public class Reader
{
    public int Id { get; set; }
    [Required, StringLength(80)]
    public string FirstName { get; set; } = "";
    [Required, StringLength(80)]
    public string LastName { get; set; } = "";
    [Phone]
    public string? Phone { get; set; }
    public string FullName => $"{FirstName} {LastName}";
}
