using LibraryWebsite.Data;
using LibraryWebsite.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LibraryWebsite.Controllers;

public class LoansController : Controller
{
    private readonly LibraryContext _db;
    public LoansController(LibraryContext db) => _db = db;

    public async Task<IActionResult> Index()
    {
        var loans = await _db.Loans.Include(l => l.Book).Include(l => l.Reader)
            .OrderByDescending(l => l.BorrowedAt).ToListAsync();
        return View(loans);
    }

    public async Task<IActionResult> Create()
    {
        ViewBag.Books = await _db.Books.Where(b => b.IsAvailable).ToListAsync();
        ViewBag.Readers = await _db.Readers.ToListAsync();
        return View();
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(int bookId, int readerId)
    {
        var book = await _db.Books.FindAsync(bookId);
        var reader = await _db.Readers.FindAsync(readerId);
        if (book == null || reader == null || !book.IsAvailable)
        {
            TempData["Message"] = "Выберите доступную книгу и зарегистрированного читателя.";
            return RedirectToAction(nameof(Create));
        }
        book.IsAvailable = false;
        _db.Loans.Add(new Loan { BookId = bookId, ReaderId = readerId,
            BorrowedAt = DateTime.Today, DueDate = DateTime.Today.AddDays(14) });
        await _db.SaveChangesAsync();
        TempData["Message"] = "Книга успешно выдана!";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Return(int id)
    {
        var loan = await _db.Loans.Include(l => l.Book).FirstOrDefaultAsync(l => l.Id == id);
        if (loan == null || loan.ReturnedAt != null) return NotFound();
        loan.ReturnedAt = DateTime.Today;
        if (loan.Book != null) loan.Book.IsAvailable = true;
        await _db.SaveChangesAsync();
        TempData["Message"] = $"Книга возвращена. Штраф: {loan.Fine:0} тг.";
        return RedirectToAction(nameof(Index));
    }
}
