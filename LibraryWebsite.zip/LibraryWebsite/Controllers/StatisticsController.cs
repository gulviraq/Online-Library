using LibraryWebsite.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LibraryWebsite.Controllers;

public class StatisticsController : Controller
{
    private readonly LibraryContext _db;
    public StatisticsController(LibraryContext db) => _db = db;
    public async Task<IActionResult> Index()
    {
        ViewBag.TotalBooks = await _db.Books.CountAsync();
        ViewBag.AvailableBooks = await _db.Books.CountAsync(b => b.IsAvailable);
        ViewBag.BorrowedBooks = await _db.Books.CountAsync(b => !b.IsAvailable);
        ViewBag.Readers = await _db.Readers.CountAsync();
        return View();
    }
}
