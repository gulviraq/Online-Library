using LibraryWebsite.Data;
using LibraryWebsite.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LibraryWebsite.Controllers;

public class ReadersController : Controller
{
    private readonly LibraryContext _db;
    public ReadersController(LibraryContext db) => _db = db;
    public async Task<IActionResult> Index() => View(await _db.Readers.OrderBy(r => r.LastName).ToListAsync());
    public IActionResult Create() => View(new Reader());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Reader reader)
    {
        if (!ModelState.IsValid) return View(reader);
        _db.Readers.Add(reader);
        await _db.SaveChangesAsync();
        TempData["Message"] = "Читатель успешно зарегистрирован!";
        return RedirectToAction(nameof(Index));
    }
}
