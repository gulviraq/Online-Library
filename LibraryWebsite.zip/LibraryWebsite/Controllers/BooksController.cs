using LibraryWebsite.Data;
using LibraryWebsite.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LibraryWebsite.Controllers;

public class BooksController : Controller
{
    private readonly LibraryContext _db;
    public BooksController(LibraryContext db) => _db = db;

    public async Task<IActionResult> Index(string? search, string? sort)
    {
        var books = _db.Books.AsQueryable();
        if (!string.IsNullOrWhiteSpace(search))
            books = books.Where(b => b.Title.Contains(search) || b.Author.Contains(search)
                || b.Year.ToString().Contains(search));
        books = sort == "year" ? books.OrderBy(b => b.Year) : books.OrderBy(b => b.Title);
        ViewBag.Search = search;
        return View(await books.ToListAsync());
    }

    public IActionResult Create() => View(new Book());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Book book)
    {
        if (!ModelState.IsValid) return View(book);
        _db.Books.Add(book);
        await _db.SaveChangesAsync();
        TempData["Message"] = "Книга успешно добавлена!";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Details(int id)
    {
        var book = await _db.Books.FindAsync(id);
        return book == null ? NotFound() : View(book);
    }

    public async Task<IActionResult> Delete(int id)
    {
        var book = await _db.Books.FindAsync(id);
        if (book == null) return NotFound();
        _db.Books.Remove(book);
        await _db.SaveChangesAsync();
        TempData["Message"] = "Книга удалена.";
        return RedirectToAction(nameof(Index));
    }
}
